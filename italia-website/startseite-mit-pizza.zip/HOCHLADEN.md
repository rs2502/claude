# Hochladen auf ristorante-pizzeria-italia.com

Per FTP in den Ordner `/start/` des Webspace laden:

| Aus diesem Paket | Ziel auf dem Server |
|---|---|
| `start/startseite.html` | `/start/startseite.html` (ersetzt die alte Datei) |
| `start/pizza-effekt/` (ganzer Ordner) | `/start/pizza-effekt/` |
| `start/assets/festsaal.jpg` | `/start/assets/festsaal.jpg` |

`start/startseite.original.html` ist die bisherige Startseite als Sicherung. Die muss nicht hochgeladen werden. Falls etwas nicht passt, einfach diese Datei wieder als `startseite.html` hochladen.

## Was sich an der Startseite geändert hat

1. Im `<head>`: eine Zeile, die `pizza-effekt.css` lädt.
2. Zwischen „Qualität, Kreativität & herzlicher Service“ und dem Bilder-Streifen steht der neue Pizza-Abschnitt. Der Bilder-Streifen bleibt erhalten.
3. Vor `</body>`: eine Zeile, die `pizza-effekt.js` lädt.

4. „Mit uns feiern Sie richtig“ hat das Festsaal-Foto als Hintergrund (`assets/festsaal.jpg`) mit leichtem Terrakotta-Schleier.
5. Showreel-Effekte: Die Hero-Überschrift gleitet Wort für Wort hoch, die Eyebrow-Linie zieht sich auf, und bei den drei Karten springt ein Terrakotta-Balken zur Karte unter Maus oder Finger.

Alles andere (Intro, Öffnungszeiten-Balken, Feiern-Effekt, Öffnungsstatus) ist unverändert.

Nach dem Hochladen die Seite einmal mit Strg+F5 (Handy: Seite neu laden) aufrufen und durch den Pizza-Abschnitt scrollen.
